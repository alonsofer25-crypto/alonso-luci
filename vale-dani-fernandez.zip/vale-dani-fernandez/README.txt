# Vale sorpresa — Dani Fernández (Valencia, 20 de marzo)

Tienes una mini‑web lista para enviar por WhatsApp/IG.

## 1) Cómo usarla (lo más simple)
### Opción A — Netlify (gratis, sin cuenta si quieres)
1. Entra en Netlify y busca **“Deploy manually / Drag and drop”** (también vale “Netlify Drop”).
2. Arrastra **este archivo `index.html`** (o la carpeta entera) a la zona de subida.
3. Netlify te dará una URL del estilo `https://xxxxx.netlify.app`.
4. Acorta la URL con bit.ly si te apetece.

### Opción B — GitHub Pages (gratis)
1. Crea un repo en GitHub (p.ej. `vale-dani`).
2. Sube `index.html`.
3. En Settings → Pages → publica desde la rama main.
4. Te quedará un link tipo `https://tuusuario.github.io/vale-dani/`.

## 2) Cambiar el texto (tu nombre, detalles, etc.)
Busca en el HTML:
- “Valencia”
- “20 de marzo”
- “Alonso 💚”
y cámbialo por lo que quieras.

## 3) Música (importante)
Por copyright y porque en móvil el autoplay suele estar bloqueado:
- La opción más limpia es que el botón abra Spotify o YouTube.

Ahora mismo el botón abre una búsqueda en Spotify.  
Si quieres que abra un tema concreto, cambia el `href` del botón:

`id="playBtn" href="..."`

Ejemplos:
- Spotify track: https://open.spotify.com/track/XXXXXXXXXXXX
- YouTube: https://youtu.be/XXXXXXXX

## 4) Si quieres que suene DENTRO de la página
Técnicamente se puede si tú aportas un audio que tengas derecho a usar.
Se añadiría un archivo `audio.mp3` en la misma carpeta y un botón play/pause.
Si quieres esto, dime y te lo preparo (con tu audio).

---

Hecho para que se vea perfecto en móvil y con efecto “desliza” + confeti 🎉
